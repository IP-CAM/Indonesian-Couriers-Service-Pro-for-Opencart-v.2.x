<?php
// Text
$_['text_title']       = 'Wahana Prestasi Logistik';
$_['text_description'] = 'Wahana Prestasi Logistik';
$_['text_days'] = 'day(s)';
$_['error_currency'] = 'JNE using IDR Currency, Please add IDR first';
