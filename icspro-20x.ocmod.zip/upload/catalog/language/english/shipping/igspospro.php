<?php
// Text
$_['text_title']       = 'POS Indonesia (POS)';
$_['text_description'] = 'POS Indonesia (POS)';
$_['text_days'] = 'day(s)';
$_['error_currency'] = 'POS using IDR Currency, Please add IDR first';
