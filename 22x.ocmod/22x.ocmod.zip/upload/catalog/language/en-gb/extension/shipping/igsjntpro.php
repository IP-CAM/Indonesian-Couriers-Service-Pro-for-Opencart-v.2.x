<?php
// Text
$_['text_title']       = 'J&T Express';
$_['text_description'] = 'J&T Express';
$_['text_days'] = 'day(s)';
$_['error_currency'] = 'JNE using IDR Currency, Please add IDR first';
