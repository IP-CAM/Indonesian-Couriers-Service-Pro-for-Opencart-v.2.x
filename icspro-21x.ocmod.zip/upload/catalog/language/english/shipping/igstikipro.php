<?php
// Text
$_['text_title']       = 'Citra Van Titipan Kilat (TIKI)
';
$_['text_description'] = 'Citra Van Titipan Kilat (TIKI)
';
$_['text_days'] = 'day(s)';
$_['error_currency'] = 'TIKI using IDR Currency, Please add IDR first';
